<?php
defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Table\Table;

class com_servicosInstallerScript
{
    public function install($parent)
    {
        $this->createDefaultCategories();
    }

    public function update($parent)
    {
        $this->createDefaultCategories();
    }

    protected function createDefaultCategories()
    {
        $db = Factory::getContainer()->get('DatabaseDriver');
        $extension = 'com_servicos';
        $categories = ['Recomendados', 'Destaque'];

        foreach ($categories as $title) {
            // Check if category exists
            $query = $db->getQuery(true)
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__categories'))
                ->where($db->quoteName('extension') . ' = ' . $db->quote($extension))
                ->where($db->quoteName('title') . ' = ' . $db->quote($title));

            $db->setQuery($query);

            if (!$db->loadResult()) {
                // Create category
                $data = [
                    'title' => $title,
                    'alias' => \Joomla\CMS\Filter\OutputFilter::stringURLSafe($title),
                    'extension' => $extension,
                    'published' => 1,
                    'access' => 1,
                    'params' => '{}',
                    'metadata' => '{}',
                    'language' => '*'
                ];

                Table::addIncludePath(JPATH_ADMINISTRATOR . '/components/com_categories/tables');
                $table = Table::getInstance('Category', 'CategoriesTable');

                if (!$table) {
                    echo Text::_('Failed to get Config table');
                    continue;
                }

                // Set location (Root)
                $table->setLocation(1, 'last-child');

                if (!$table->save($data)) {
                    // Log error if needed, but fail silently for user
                    // Factory::getApplication()->enqueueMessage($table->getError(), 'warning');
                }
            }
        }
    }
}
