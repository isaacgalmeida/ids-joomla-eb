<?php
/**
 * @package     IDS.Administrator
 * @subpackage  com_pagtesouro
 *
 * @copyright   Copyright (C) 2025 Astatonn. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace IDS\Component\PagTesouro\Administrator\Model;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Model\ListModel;
use Joomla\Database\ParameterType;

/**
 * Methods supporting a list of Servico records.
 *
 * @since  3.0.0
 */
class ServicosModel extends ListModel
{
    /**
     * Constructor.
     *
     * @param   array  $config  An optional associative array of configuration settings.
     *
     * @see     \Joomla\CMS\MVC\Controller\BaseController
     * @since   3.0.0
     */
    public function __construct($config = [])
    {
        if (empty($config['filter_fields'])) {
            $config['filter_fields'] = [
                'id', 'a.id',
                'uasg_id', 'a.uasg_id',
                'codigo', 'a.codigo',
                'descricao', 'a.descricao',
                'state', 'a.state',
                'uasg_descricao', 'u.descricao'
            ];
        }

        parent::__construct($config);
    }

    /**
     * Method to auto-populate the model state.
     *
     * @param   string  $ordering   An optional ordering field.
     * @param   string  $direction  An optional direction (asc|desc).
     *
     * @return  void
     *
     * @since   3.0.0
     */
    protected function populateState($ordering = 'a.descricao', $direction = 'asc'): void
    {
        $search = $this->getUserStateFromRequest($this->context . '.filter.search', 'filter_search', '', 'string');
        $this->setState('filter.search', $search);

        $published = $this->getUserStateFromRequest($this->context . '.filter.state', 'filter_state', '', 'string');
        $this->setState('filter.state', $published);

        $uasgId = $this->getUserStateFromRequest($this->context . '.filter.uasg_id', 'filter_uasg_id', '', 'int');
        $this->setState('filter.uasg_id', $uasgId);

        parent::populateState($ordering, $direction);
    }

    /**
     * Method to get a store id based on model configuration state.
     *
     * @param   string  $id  A prefix for the store id.
     *
     * @return  string  A store id.
     *
     * @since   3.0.0
     */
    protected function getStoreId($id = ''): string
    {
        $id .= ':' . $this->getState('filter.search');
        $id .= ':' . $this->getState('filter.state');
        $id .= ':' . $this->getState('filter.uasg_id');

        return parent::getStoreId($id);
    }

    /**
     * Build an SQL query to load the list data.
     *
     * @return  \Joomla\Database\DatabaseQuery
     *
     * @since   3.0.0
     */
    protected function getListQuery()
    {
        $db = $this->getDatabase();
        $query = $db->getQuery(true);

        // Select fields
        $query->select('a.*')
            ->select($db->quoteName('u.descricao', 'uasg_descricao'))
            ->from($db->quoteName('#__pagtesouro_servicos', 'a'))
            ->join('LEFT', $db->quoteName('#__pagtesouro_uasgs', 'u'), 'u.id = a.uasg_id');

        // Filter by published state
        $state = $this->getState('filter.state');
        if (is_numeric($state)) {
            $state = (int) $state;
            $query->where($db->quoteName('a.state') . ' = :state')
                ->bind(':state', $state, ParameterType::INTEGER);
        }

        // Filter by UASG
        $uasgId = $this->getState('filter.uasg_id');
        if (is_numeric($uasgId)) {
            $uasgId = (int) $uasgId;
            $query->where($db->quoteName('a.uasg_id') . ' = :uasgid')
                ->bind(':uasgid', $uasgId, ParameterType::INTEGER);
        }

        // Filter by search
        $search = $this->getState('filter.search');
        if (!empty($search)) {
            if (stripos($search, 'id:') === 0) {
                $ids = (int) substr($search, 3);
                $query->where($db->quoteName('a.id') . ' = :id')
                    ->bind(':id', $ids, ParameterType::INTEGER);
            } else {
                $search = '%' . str_replace(' ', '%', $db->escape(trim($search), true)) . '%';
                $query->where(
                    '(' . $db->quoteName('a.descricao') . ' LIKE :search1'
                    . ' OR ' . $db->quoteName('a.codigo') . ' LIKE :search2)'
                )->bind([':search1', ':search2'], $search);
            }
        }

        // Ordering
        $orderCol = $this->state->get('list.ordering', 'a.descricao');
        $orderDirn = $this->state->get('list.direction', 'asc');
        $query->order($db->escape($orderCol) . ' ' . $db->escape($orderDirn));

        return $query;
    }
}
