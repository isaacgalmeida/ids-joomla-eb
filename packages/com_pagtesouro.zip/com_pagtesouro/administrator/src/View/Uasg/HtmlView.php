<?php
namespace IDS\Component\PagTesouro\Administrator\View\Uasg;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;

class HtmlView extends BaseHtmlView
{
    protected $item;
    protected $form;

    public function display($tpl = null)
    {
        $this->item = $this->get('Item');
        $this->form = $this->get('Form');

        $this->addToolbar();
        return parent::display($tpl);
    }

    protected function addToolbar()
    {
        $isNew = ($this->item->id == 0);
        ToolbarHelper::title(Text::_('COM_PAGTESOURO_UASG_' . ($isNew ? 'NEW' : 'EDIT')), 'pencil-2');
        ToolbarHelper::apply('uasg.apply');
        ToolbarHelper::save('uasg.save');
        ToolbarHelper::cancel('uasg.cancel');
    }
}
