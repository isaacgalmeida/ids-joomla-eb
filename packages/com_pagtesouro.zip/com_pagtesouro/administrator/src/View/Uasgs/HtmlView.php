<?php
namespace IDS\Component\PagTesouro\Administrator\View\Uasgs;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\View\HtmlView as BaseHtmlView;
use Joomla\CMS\Toolbar\ToolbarHelper;
use Joomla\CMS\Language\Text;

class HtmlView extends BaseHtmlView
{
    protected $items;
    protected $pagination;
    protected $state;

    public function display($tpl = null)
    {
        $this->items = $this->get('Items');
        $this->pagination = $this->get('Pagination');
        $this->state = $this->get('State');

        $this->addToolbar();
        return parent::display($tpl);
    }

    protected function addToolbar()
    {
        ToolbarHelper::title(Text::_('COM_PAGTESOURO_UASGS'), 'list');
        ToolbarHelper::addNew('uasg.add');
        ToolbarHelper::editList('uasg.edit');
        ToolbarHelper::deleteList('JGLOBAL_CONFIRM_DELETE', 'uasgs.delete');
        ToolbarHelper::preferences('com_pagtesouro');
    }
}
