<?php
/**
 * @package     IDS.Administrator
 * @subpackage  com_pagtesouro
 *
 * @copyright   Copyright (C) 2025 Astatonn. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace IDS\Component\PagTesouro\Administrator\Table;

\defined('_JEXEC') or die;

use Joomla\CMS\Table\Table;
use Joomla\Database\DatabaseDriver;

/**
 * UASG Table class.
 *
 * @since  3.0.0
 */
class UasgTable extends Table
{
    /**
     * Constructor
     *
     * @param   DatabaseDriver  $db  Database connector object
     *
     * @since   3.0.0
     */
    public function __construct(DatabaseDriver $db)
    {
        parent::__construct('#__pagtesouro_uasgs', 'id', $db);
    }

    /**
     * Method to perform sanity checks on the Table instance properties to ensure they are safe to store in the database.
     *
     * @return  boolean  True if the instance is sane and able to be stored in the database.
     *
     * @since   3.0.0
     */
    public function check(): bool
    {
        // Check for valid orgao
        if (trim($this->orgao) == '') {
            $this->setError('Órgão é obrigatório');
            return false;
        }

        // Check for valid ug
        if (trim($this->ug) == '') {
            $this->setError('UG é obrigatória');
            return false;
        }

        // Check for valid descricao
        if (trim($this->descricao) == '') {
            $this->setError('Descrição é obrigatória');
            return false;
        }

        return true;
    }
}
