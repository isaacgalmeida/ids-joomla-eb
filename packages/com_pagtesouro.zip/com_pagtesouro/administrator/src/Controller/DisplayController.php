<?php
/**
 * @package     IDS.Administrator
 * @subpackage  com_pagtesouro
 *
 * @copyright   Copyright (C) 2025 Astatonn. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace IDS\Component\PagTesouro\Administrator\Controller;

\defined('_JEXEC') or die;

use Joomla\CMS\MVC\Controller\BaseController;

/**
 * PagTesouro master display controller.
 *
 * @since  3.0.0
 */
class DisplayController extends BaseController
{
    /**
     * The default view.
     *
     * @var    string
     * @since  3.0.0
     */
    protected $default_view = 'uasgs';

    /**
     * Method to display a view.
     *
     * @param   boolean  $cachable   If true, the view output will be cached
     * @param   array    $urlparams  An array of safe URL parameters and their variable types,
     *                                for valid values see {@link \Joomla\CMS\Filter\InputFilter::clean()}.
     *
     * @return  static  This object to support chaining.
     *
     * @since   3.0.0
     */
    public function display($cachable = false, $urlparams = []): static
    {
        return parent::display($cachable, $urlparams);
    }
}
