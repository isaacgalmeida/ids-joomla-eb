<?php
/**
 * @package     IDS.Component
 * @subpackage  com_pagtesouro
 *
 * @copyright   Copyright (C) 2025 Astatonn. All rights reserved.
 * @license     GNU General Public License version 2 or later
 */

\defined('_JEXEC') or die;

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScript;
use Joomla\CMS\Language\Text;

/**
 * Script file for PagTesouro component
 *
 * @since  3.0.0
 */
class Com_PagTesouroInstallerScript extends InstallerScript
{
    /**
     * Minimum PHP version required
     *
     * @var    string
     * @since  3.0.0
     */
    protected $minimumPhp = '8.3.0';

    /**
     * Minimum Joomla version required
     *
     * @var    string
     * @since  3.0.0
     */
    protected $minimumJoomla = '5.4.0';

    /**
     * Method called before install/update/discover_install
     *
     * @param   string            $type    Type of install
     * @param   InstallerAdapter  $parent  Parent installer
     *
     * @return  boolean  True on success
     *
     * @since   3.0.0
     */
    public function preflight($type, $parent)
    {
        if (!parent::preflight($type, $parent)) {
            return false;
        }

        $app = Factory::getApplication();

        // Verificar se está migrando da versão 2.x (legacy)
        if ($type === 'update') {
            $db = Factory::getDbo();
            $query = $db->getQuery(true)
                ->select('manifest_cache')
                ->from('#__extensions')
                ->where('type = ' . $db->quote('component'))
                ->where('element = ' . $db->quote('com_pagtesouro'));

            $db->setQuery($query);
            $manifest = json_decode($db->loadResult(), true);

            if ($manifest && isset($manifest['version'])) {
                $oldVersion = $manifest['version'];

                if (version_compare($oldVersion, '3.0.0', '<')) {
                    $app->enqueueMessage(
                        Text::sprintf(
                            'Atualizando de versão %s para 3.0.0. ' .
                            'Esta é uma atualização MAJOR com mudanças significativas na arquitetura. ' .
                            'O componente foi completamente refatorado para Joomla 6 com namespace moderno.',
                            $oldVersion
                        ),
                        'warning'
                    );
                }
            }
        }

        // Verificar Joomla 6
        $jVersion = new \Joomla\CMS\Version();
        if (version_compare($jVersion->getShortVersion(), '6.0', '>=')) {
            $app->enqueueMessage(
                'Joomla 6 detectado. Componente totalmente compatível com a nova arquitetura!',
                'info'
            );
        }

        return true;
    }

    /**
     * Method called after install/update/discover_install
     *
     * @param   string            $type    Type of install
     * @param   InstallerAdapter  $parent  Parent installer
     *
     * @return  boolean  True on success
     *
     * @since   3.0.0
     */
    public function postflight($type, $parent)
    {
        if (!parent::postflight($type, $parent)) {
            return false;
        }

        $app = Factory::getApplication();

        if ($type === 'install' || $type === 'update') {
            $app->enqueueMessage(
                '<h4>PagTesouro 3.0 - Arquitetura Moderna</h4>' .
                '<ul>' .
                '<li>✅ Namespace: IDS\Component\PagTesouro</li>' .
                '<li>✅ Service Provider implementado</li>' .
                '<li>✅ Código PHP 8.3+ com tipagem forte</li>' .
                '<li>✅ Estrutura MVC moderna do Joomla 6</li>' .
                '<li>✅ Atualizações automáticas habilitadas</li>' .
                '</ul>',
                'success'
            );
        }

        return true;
    }
}
